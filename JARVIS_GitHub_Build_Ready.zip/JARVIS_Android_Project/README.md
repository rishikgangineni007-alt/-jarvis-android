# JARVIS Personal Android Starter

A lightweight Kotlin Android starter project for a Redmi 9A-class device. It includes:
- Native Android UI
- Speech-to-text through Android's `SpeechRecognizer` service
- Text-to-speech through Android `TextToSpeech`
- Local commands: time/date, battery, launch YouTube/Chrome/WhatsApp/camera, open Android/Wi-Fi/Bluetooth/display settings
- OpenAI-compatible Chat Completions endpoint settings
- Short conversation history stored in app preferences

## Build an APK

Recommended: Android Studio on a computer.

1. Install Android Studio and its Android SDK (API 35).
2. Unzip this project.
3. In Android Studio, choose **Open** and select the `JARVIS_Android_Project` folder.
4. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35 and compatible build tools.
5. Connect the Redmi 9A with USB debugging enabled, or use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. For a debug build, Android Studio normally creates:
   `app/build/outputs/apk/debug/app-debug.apk`
7. Transfer the APK to the phone and install it. You may need to allow installation from that file manager.
8. Open JARVIS and grant microphone permission if you want voice input.

## Cloud AI configuration

In JARVIS > Cloud AI Settings:
- API URL: `https://api.openai.com/v1/chat/completions` for an OpenAI-compatible Chat Completions API.
- Model: enter a model available to your API account.
- API key: paste your own API key and tap Save AI Settings.

This starter does not include an API key. API usage can incur charges according to your provider's pricing. Keep the key private; this prototype stores it in app preferences and is not hardened like a production credential vault. For a production app, put the key behind your own backend rather than shipping it inside an APK.

For other compatible providers, use their documented HTTPS Chat Completions endpoint and model identifier.

## Current limitations

- This is starter source code, not a prebuilt or signed APK. Build it with Android Studio.
- Speech recognition availability/offline support depends on the installed recognition service and language packs.
- Android may prevent launching apps that are not installed or expose certain settings/actions.
- No always-on wake word, background listening service, notification reading, SMS sending, or unrestricted phone control is included.
- `QUERY_ALL_PACKAGES` is broad and may be rejected by some distribution channels; remove it and use a package visibility allowlist if publishing.
- Conversation history is local app data. Clearing app data removes it.
- The current API adapter expects an OpenAI-compatible Chat Completions response shape (`choices[0].message.content`).

## Troubleshooting

- If Gradle asks to update plugins, first try the versions in this project with a current Android Studio release.
- If API calls fail, verify the URL, model, key, provider account, and internet access.
- If voice does not work, check Android Settings > Apps > JARVIS > Permissions > Microphone, and ensure a speech recognition service is installed.
