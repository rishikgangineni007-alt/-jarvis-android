PHONE-ONLY CLOUD BUILD (GitHub Actions)

1. Create/sign in to a GitHub account.
2. In GitHub, create a NEW PUBLIC repository named jarvis-android (public is easiest for Actions on a free account).
3. On the repository page choose Add file > Upload files.
4. Extract this ZIP on your phone first, then upload the CONTENTS of the JARVIS_Android_Project folder (including the hidden .github folder). If your file manager hides .github, use GitHub's web interface to create .github/workflows/build-apk.yml and paste the workflow from this project.
5. Commit the files to the main branch.
6. Open the repository's Actions tab. Select "Build JARVIS APK" and press Run workflow if it has not started automatically.
7. Wait for the workflow to finish successfully. Open the completed run and download the "JARVIS-debug-apk" artifact. GitHub may download it as a ZIP; extract it to get app-debug.apk.
8. Tap app-debug.apk to install. Android may ask you to allow installs from your browser or file manager.

Security: do not add your AI API key to GitHub source files. The project should be built without a key; enter your key only inside the installed app. A public repository exposes source code, so never upload passwords, API keys, or private data.
