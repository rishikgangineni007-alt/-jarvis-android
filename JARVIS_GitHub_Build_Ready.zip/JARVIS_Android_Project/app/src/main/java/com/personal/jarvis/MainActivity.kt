package com.personal.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private val bg = Color.rgb(5, 11, 20)
    private val panel = Color.rgb(12, 24, 39)
    private val cyan = Color.rgb(67, 217, 255)
    private val white = Color.rgb(230, 244, 255)
    private val executor = Executors.newSingleThreadExecutor()

    private lateinit var status: TextView
    private lateinit var transcript: TextView
    private lateinit var input: EditText
    private lateinit var endpoint: EditText
    private lateinit var apiKey: EditText
    private lateinit var model: EditText
    private lateinit var speakButton: Button
    private lateinit var tts: TextToSpeech
    private var speech: SpeechRecognizer? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        tts = TextToSpeech(this, this)
        buildUi()
        restoreSettings()
        showMessage("JARVIS", "Systems online. How may I assist?")
        status.text = "READY • HYBRID MODE"
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(14))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(10))
        }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "J.A.R.V.I.S."
            textSize = 28f
            letterSpacing = 0.18f
            setTextColor(cyan)
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        content.addView(title, matchWrap())
        content.addView(TextView(this).apply {
            text = "PERSONAL AI SYSTEM  /  ANDROID"
            textSize = 10f
            letterSpacing = 0.12f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(18))
        }, matchWrap())

        val orb = TextView(this).apply {
            text = "◉"
            textSize = 78f
            gravity = Gravity.CENTER
            setTextColor(cyan)
            setPadding(0, dp(5), 0, dp(2))
        }
        content.addView(orb, matchWrap())

        status = TextView(this).apply {
            text = "INITIALIZING"
            textSize = 12f
            letterSpacing = 0.12f
            setTextColor(cyan)
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(18))
        }
        content.addView(status, matchWrap())

        transcript = TextView(this).apply {
            text = ""
            textSize = 14f
            setTextColor(white)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(panel)
            minHeight = dp(150)
            gravity = Gravity.TOP
        }
        content.addView(transcript, LinearLayout.LayoutParams(-1, dp(190)).apply {
            bottomMargin = dp(12)
        })

        input = EditText(this).apply {
            hint = "Ask JARVIS anything..."
            setHintTextColor(Color.GRAY)
            setTextColor(white)
            textSize = 15f
            singleLine = false
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
        }
        content.addView(input, matchWrap())

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        speakButton = makeButton("🎙  TALK") { startListening() }
        actions.addView(speakButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            rightMargin = dp(6)
            topMargin = dp(8)
        })
        actions.addView(makeButton("SEND  ➤") { sendText() },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                leftMargin = dp(6)
                topMargin = dp(8)
            })
        content.addView(actions, matchWrap())

        content.addView(section("CLOUD AI SETTINGS"))
        endpoint = makeEdit("OpenAI-compatible API URL")
        model = makeEdit("Model name")
        apiKey = makeEdit("API key (kept on this device)")
        apiKey.inputType = 129
        content.addView(endpoint, matchWrap())
        content.addView(model, matchWrap().apply { topMargin = dp(7) })
        content.addView(apiKey, matchWrap().apply { topMargin = dp(7) })
        content.addView(makeButton("SAVE AI SETTINGS") { saveSettings(); showMessage("JARVIS", "AI settings saved on this device.") },
            matchWrap().apply { topMargin = dp(8) })

        content.addView(section("QUICK COMMANDS"))
        val quick = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listOf(
            "Open YouTube" to "open youtube",
            "Open Settings" to "open settings",
            "Battery status" to "battery status",
            "What time is it?" to "what time is it"
        ).forEach { (label, command) ->
            quick.addView(makeButton(label) { handlePrompt(command) },
                matchWrap().apply { topMargin = dp(5) })
        }
        content.addView(quick, matchWrap())
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        letterSpacing = 0.12f
        setTextColor(cyan)
        setPadding(0, dp(22), 0, dp(9))
    }

    private fun makeEdit(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.GRAY)
        setTextColor(white)
        textSize = 13f
        setPadding(dp(12), dp(10), dp(12), dp(10))
        setBackgroundColor(panel)
        singleLine = true
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 12f
        isAllCaps = false
        setTextColor(cyan)
        setBackgroundColor(panel)
        setOnClickListener { action() }
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts.language = Locale.getDefault()
    }

    private fun restoreSettings() {
        val prefs = getSharedPreferences("jarvis", MODE_PRIVATE)
        endpoint.setText(prefs.getString("endpoint", "https://api.openai.com/v1/chat/completions"))
        model.setText(prefs.getString("model", "gpt-4o-mini"))
        apiKey.setText(prefs.getString("key", ""))
    }

    private fun saveSettings() {
        getSharedPreferences("jarvis", MODE_PRIVATE).edit()
            .putString("endpoint", endpoint.text.toString().trim())
            .putString("model", model.text.toString().trim())
            .putString("key", apiKey.text.toString().trim())
            .apply()
    }

    private fun sendText() {
        val prompt = input.text.toString().trim()
        if (prompt.isEmpty()) return
        input.setText("")
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(input.windowToken, 0)
        handlePrompt(prompt)
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            showMessage("JARVIS", "Speech recognition is unavailable on this device. Please type your request.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 200)
            return
        }
        try {
            if (speech == null) speech = SpeechRecognizer.createSpeechRecognizer(this)
            speech?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "LISTENING..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "PROCESSING..." }
                override fun onError(error: Int) {
                    status.text = "READY • TRY AGAIN"
                    showMessage("JARVIS", "I couldn't recognize that. Try again or type your command.")
                }
                override fun onResults(results: Bundle?) {
                    val spoken = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    status.text = "READY • HYBRID MODE"
                    if (!spoken.isNullOrBlank()) handlePrompt(spoken)
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
            }
            speech?.startListening(intent)
        } catch (_: Exception) {
            status.text = "READY • TRY AGAIN"
            showMessage("JARVIS", "Could not start voice recognition. You can type instead.")
        }
    }

    private fun handlePrompt(raw: String) {
        val prompt = raw.trim()
        showMessage("YOU", prompt)
        val p = prompt.lowercase(Locale.ROOT)

        when {
            p.contains("open settings") || p == "settings" -> {
                startActivity(Intent(Settings.ACTION_SETTINGS))
                answer("Opening Android Settings.")
            }
            p.contains("wifi settings") || p.contains("wi-fi settings") -> {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                answer("Opening Wi-Fi settings.")
            }
            p.contains("bluetooth settings") -> {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                answer("Opening Bluetooth settings.")
            }
            p.contains("display settings") -> {
                startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS))
                answer("Opening display settings.")
            }
            p.contains("open youtube") -> launchPackage("com.google.android.youtube", "YouTube")
            p.contains("open chrome") -> launchPackage("com.android.chrome", "Chrome")
            p.contains("open whatsapp") -> launchPackage("com.whatsapp", "WhatsApp")
            p.contains("open camera") -> {
                val i = Intent("android.media.action.IMAGE_CAPTURE")
                try { startActivity(i); answer("Opening camera.") }
                catch (_: Exception) { answer("I couldn't find a camera app.") }
            }
            p.contains("battery") -> {
                val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
                val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                answer("Your battery is at $level percent.")
            }
            p.contains("what time") || p == "time" || p.contains("current time") ->
                answer("The time is " + java.text.SimpleDateFormat("h:mm a", Locale.getDefault()).format(java.util.Date()))
            p.contains("what date") || p.contains("today's date") ->
                answer("Today is " + java.text.SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(java.util.Date()))
            p == "help" || p.contains("what can you do") ->
                answer("I can tell the time and battery level, open supported apps and Android settings, and answer broader questions through your configured cloud AI.")
            else -> askCloud(prompt)
        }
    }

    private fun launchPackage(packageName: String, displayName: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            answer("Opening $displayName.")
        } else {
            answer("$displayName doesn't appear to be installed.")
        }
    }

    private fun askCloud(prompt: String) {
        saveSettings()
        val urlText = endpoint.text.toString().trim()
        val key = apiKey.text.toString().trim()
        val modelName = model.text.toString().trim()
        if (urlText.isBlank() || key.isBlank() || modelName.isBlank()) {
            answer("That needs my cloud AI. Open Cloud AI Settings, add your compatible API URL, model name and API key, then save. Local commands still work without those settings.")
            return
        }
        if (!urlText.startsWith("https://")) {
            answer("For safety, the cloud endpoint must use HTTPS.")
            return
        }
        status.text = "THINKING..."
        executor.execute {
            var connection: HttpURLConnection? = null
            try {
                val history = getSharedPreferences("jarvis", MODE_PRIVATE)
                    .getString("history", "[]") ?: "[]"
                val messages = JSONArray(history)
                messages.put(JSONObject().put("role", "user").put("content", prompt))
                // Keep a small recent window to limit request size on entry-level phones.
                val recent = JSONArray()
                val start = maxOf(0, messages.length() - 12)
                for (i in start until messages.length()) recent.put(messages.getJSONObject(i))
                val body = JSONObject()
                    .put("model", modelName)
                    .put("messages", recent)
                    .put("temperature", 0.7)
                connection = (URL(urlText).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Authorization", "Bearer $key")
                }
                connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() } ?: ""
                if (code !in 200..299) throw Exception("API returned HTTP $code: ${response.take(240)}")
                val json = JSONObject(response)
                val reply = json.getJSONArray("choices").getJSONObject(0)
                    .getJSONObject("message").getString("content").trim()
                messages.put(JSONObject().put("role", "assistant").put("content", reply))
                val saved = JSONArray()
                val keepStart = maxOf(0, messages.length() - 20)
                for (i in keepStart until messages.length()) saved.put(messages.getJSONObject(i))
                getSharedPreferences("jarvis", MODE_PRIVATE).edit().putString("history", saved.toString()).apply()
                runOnUiThread {
                    status.text = "READY • HYBRID MODE"
                    answer(reply)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "READY • HYBRID MODE"
                    answer("I couldn't reach the cloud AI. Check your internet, endpoint, model and API key. Details: ${e.message ?: "connection error"}")
                }
            } finally {
                connection?.disconnect()
            }
        }
    }

    private fun answer(text: String) {
        showMessage("JARVIS", text)
        if (ttsReady) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun showMessage(who: String, text: String) {
        runOnUiThread {
            val previous = transcript.text.toString()
            val combined = if (previous.isBlank()) "$who\n$text" else "$previous\n\n$who\n$text"
            transcript.text = combined.takeLast(4000)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 200 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 200) {
            showMessage("JARVIS", "Microphone permission is needed for voice input. You can still type.")
        }
    }

    override fun onDestroy() {
        speech?.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        executor.shutdownNow()
        super.onDestroy()
    }
}
